<?php

session_start();

require "../app/core/init.php";

//I know it is a weird way to write an if statement
DEBUG ? ini_set('display_errors', 1) : ini_set('display_errors', 0);
 
$app = new App;
$app->loadPageController();