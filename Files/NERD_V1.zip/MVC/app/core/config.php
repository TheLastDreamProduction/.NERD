<?php

if($_SERVER['SERVER_NAME'] = 'localhost')
{
    //DB config
    define('DBNAME', 'my_db');
    define('DBHOST', 'localhost');
    define('DBUSER', 'root');
    define('DBPASS', '');
    define('DBDRIVER', 'mysql');

    //local host verison
    define('ROOT', 'http://localhost/MVC/public');
}
else
{
    //DB config
    define('DBNAME', '');
    define('DBHOST', '');
    define('DBUSER', '');
    define('DBPASS', '');
    define('DBDRIVER', '');

    //server verison
    define('ROOT', 'https://yourwebsite.com');
}

define('APP_NAME', "My Website");
define('APP_DESC', "It is for nerds");

//true mean we are still developing and show errors for all the nerdies out there
define('DEBUG', true);