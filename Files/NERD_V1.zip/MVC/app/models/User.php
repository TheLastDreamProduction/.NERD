<?php

class User
{
    use Model;

    protected $table = 'users';

    //Customize as you like and suits your project
    protected $allowedColumns = [
        'name',
        'age',
    ];
}